
BenchmarkDotNet v0.15.8, Windows 11 (10.0.22631.6649/23H2/2023Update/SunValley3)
Intel Core Ultra 7 165H 3.80GHz, 1 CPU, 22 logical and 16 physical cores
.NET SDK 10.0.101
  [Host]     : .NET 8.0.24 (8.0.24, 8.0.2426.7010), X64 RyuJIT x86-64-v3
  Job-CNUJVU : .NET 8.0.24 (8.0.24, 8.0.2426.7010), X64 RyuJIT x86-64-v3

InvocationCount=1  UnrollFactor=1  

 Method                                   | Mean        | Error      | StdDev     | Median      | Ratio        | RatioSD | Rank | Allocated  | Alloc Ratio |
----------------------------------------- |------------:|-----------:|-----------:|------------:|-------------:|--------:|-----:|-----------:|------------:|
 'Bulk Entities (10) - System.Text.Json'  |   125.71 μs |   4.351 μs |  12.485 μs |   123.60 μs |     baseline |         |    1 |   11.51 KB |             |
 'Bulk Entities (10) - Kiota'             |   671.33 μs |  34.396 μs |  98.689 μs |   653.70 μs | 5.39x slower |   0.94x |    2 |  132.23 KB | 11.49x more |
                                          |             |            |            |             |              |         |      |            |             |
 'Bulk Entities (100) - System.Text.Json' |   878.21 μs |  30.193 μs |  86.142 μs |   864.25 μs |     baseline |         |    1 |   82.23 KB |             |
 'Bulk Entities (100) - Kiota'            | 4,937.92 μs | 196.070 μs | 536.738 μs | 5,013.90 μs | 5.67x slower |   0.81x |    2 | 1216.69 KB | 14.80x more |
                                          |             |            |            |             |              |         |      |            |             |
 'Complex Entity - System.Text.Json'      |   220.68 μs |   8.921 μs |  25.883 μs |   212.90 μs |     baseline |         |    1 |   19.23 KB |             |
 'Complex Entity - Kiota'                 | 1,225.38 μs |  50.327 μs | 142.770 μs | 1,201.00 μs | 5.62x slower |   0.90x |    2 |  278.34 KB | 14.48x more |
                                          |             |            |            |             |              |         |      |            |             |
 'EntityResponse - System.Text.Json'      |   218.66 μs |   7.493 μs |  21.976 μs |   213.35 μs |     baseline |         |    1 |    19.3 KB |             |
 'EntityResponse - Kiota'                 | 1,710.23 μs | 207.566 μs | 592.197 μs | 1,812.90 μs | 7.89x slower |   2.83x |    2 |  279.52 KB | 14.48x more |
                                          |             |            |            |             |              |         |      |            |             |
 'Simple Entity - System.Text.Json'       |    41.97 μs |   1.138 μs |   3.037 μs |    42.20 μs |     baseline |         |    1 |    3.52 KB |             |
 'Simple Entity - Kiota'                  |   313.09 μs |  18.138 μs |  51.454 μs |   295.10 μs | 7.50x slower |   1.35x |    2 |   23.19 KB |  6.60x more |
