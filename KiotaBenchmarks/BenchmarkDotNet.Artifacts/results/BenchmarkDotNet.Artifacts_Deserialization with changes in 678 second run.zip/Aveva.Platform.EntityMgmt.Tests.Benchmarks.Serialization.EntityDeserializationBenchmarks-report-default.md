
BenchmarkDotNet v0.15.8, Windows 11 (10.0.22631.6649/23H2/2023Update/SunValley3)
Intel Core Ultra 7 165H 3.80GHz, 1 CPU, 22 logical and 16 physical cores
.NET SDK 10.0.101
  [Host]     : .NET 8.0.24 (8.0.24, 8.0.2426.7010), X64 RyuJIT x86-64-v3
  Job-CNUJVU : .NET 8.0.24 (8.0.24, 8.0.2426.7010), X64 RyuJIT x86-64-v3

InvocationCount=1  UnrollFactor=1  

 Method                                   | Mean        | Error     | StdDev    | Ratio        | RatioSD | Rank | Allocated | Alloc Ratio |
----------------------------------------- |------------:|----------:|----------:|-------------:|--------:|-----:|----------:|------------:|
 'Bulk Entities (10) - System.Text.Json'  |   114.00 μs |  2.970 μs |  8.377 μs |     baseline |         |    1 |  11.51 KB |             |
 'Bulk Entities (10) - Kiota'             |   268.79 μs |  4.895 μs |  4.340 μs | 2.37x slower |   0.19x |    2 |  64.39 KB |  5.60x more |
                                          |             |           |           |              |         |      |           |             |
 'Bulk Entities (100) - System.Text.Json' |   769.22 μs | 12.652 μs | 10.565 μs |     baseline |         |    1 |  82.23 KB |             |
 'Bulk Entities (100) - Kiota'            | 2,269.65 μs | 39.985 μs | 74.115 μs | 2.95x slower |   0.10x |    2 | 632.05 KB |  7.69x more |
                                          |             |           |           |              |         |      |           |             |
 'Complex Entity - System.Text.Json'      |   200.92 μs |  3.965 μs |  8.786 μs |     baseline |         |    1 |  19.23 KB |             |
 'Complex Entity - Kiota'                 |   549.54 μs | 10.935 μs | 30.843 μs | 2.74x slower |   0.19x |    2 | 116.01 KB |  6.03x more |
                                          |             |           |           |              |         |      |           |             |
 'EntityResponse - System.Text.Json'      |   186.74 μs |  3.297 μs |  2.753 μs |     baseline |         |    1 |   19.3 KB |             |
 'EntityResponse - Kiota'                 |   602.35 μs | 13.306 μs | 37.310 μs | 3.23x slower |   0.20x |    2 | 117.19 KB |  6.07x more |
                                          |             |           |           |              |         |      |           |             |
 'Simple Entity - System.Text.Json'       |    44.83 μs |  1.660 μs |  4.815 μs |     baseline |         |    1 |   3.52 KB |             |
 'Simple Entity - Kiota'                  |    66.34 μs |  2.049 μs |  5.946 μs | 1.50x slower |   0.20x |    2 |   7.05 KB |  2.01x more |
